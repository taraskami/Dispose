# Dispose

## HackRPI project
> By: Taras Kaminsky, Gary Wang, Karthik Imayavaramban, and Howard Zhao

> This project will allow users to self-report locations of dumpsters and their current status for fullness (empty, semifull, full, overflowing). 
